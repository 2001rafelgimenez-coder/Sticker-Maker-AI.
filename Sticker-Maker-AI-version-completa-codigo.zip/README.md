# Sticker Maker AI — Android source 1.0

## Funciones implementadas en el código
- Elegir un video desde la galería.
- Seleccionar inicio y final del fragmento.
- Generar un WebP animado sin audio a 512x512, 12 fps, con duración máxima de 10 segundos y comprobación de límite de 500 KB.
- Generar un MP4 recortado con audio AAC original y compartirlo desde Android (por ejemplo, WhatsApp).
- El procesamiento se realiza localmente en el teléfono.

## Límites y cosas pendientes
- El WebP se genera con fondo negro/relleno; no se elimina automáticamente el fondo del video.
- El archivo WebP se comparte como archivo/imagen; esta versión todavía no incluye el ContentProvider y la pantalla de paquetes necesarios para que WhatsApp lo importe como un paquete de stickers dentro de su bandeja.
- La creación de un video con sonido no es un sticker nativo de WhatsApp: se envía como video.
- La compilación debe probarse en Android Studio y en un teléfono real. La dependencia FFmpegKit está archivada/deprecada y puede requerir sustituirse por una compilación mantenida si Maven no la resuelve.

## Compilar
1. Instalar Android Studio en una computadora.
2. Abrir esta carpeta con **Open**.
3. Esperar Gradle Sync.
4. Ejecutar en un Android conectado por USB o en un emulador.

Este paquete es código fuente, no un APK ya compilado. No se ha probado todavía en un dispositivo real.
