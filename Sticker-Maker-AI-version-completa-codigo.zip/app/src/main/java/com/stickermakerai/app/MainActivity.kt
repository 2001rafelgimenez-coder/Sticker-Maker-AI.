package com.stickermakerai.app

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StickerMakerScreen() }
    }
}

@Composable
private fun StickerMakerScreen() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startSec by remember { mutableFloatStateOf(0f) }
    var endSec by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Elegí un video para comenzar") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        videoUri = uri
        if (uri != null) {
            try {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                durationMs = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION
                )?.toLongOrNull() ?: 0L
                retriever.release()
                val seconds = (durationMs / 1000f).coerceAtLeast(1f)
                startSec = 0f
                endSec = seconds.coerceAtMost(5f)
                status = "Video listo • ${String.format(Locale.US, "%.1f", seconds)} segundos"
            } catch (_: Exception) {
                status = "No pude leer ese video. Probá con otro archivo."
            }
        }
    }

    val bg = Brush.verticalGradient(
        listOf(Color(0xFF100B25), Color(0xFF25104A), Color(0xFF090914))
    )

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF00E5FF), secondary = Color(0xFFFF2BD6),
        surface = Color(0xFF21183A), background = Color(0xFF100B25)
    )) {
        Column(
            Modifier.fillMaxSize().background(bg).padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(14.dp))
            Text("STICKER MAKER AI", color = Color(0xFF00E5FF),
                fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text("CREÁ • ANIMÁ • COMPARTÍ", color = Color.LightGray,
                fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(20.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF21183A)),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(17.dp)) {
                    Text("1. Elegí tu video", color = Color.White,
                        fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { picker.launch("video/*") },
                        modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Movie, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Abrir galería de videos")
                    }
                    Text(status, color = Color(0xFFBDB4D4), fontSize = 12.sp)
                    if (videoUri != null && durationMs > 0) {
                        Spacer(Modifier.height(14.dp))
                        Text("2. Elegí el fragmento", color = Color.White,
                            fontWeight = FontWeight.Bold)
                        Text("Inicio: ${"%.1f".format(startSec)} s",
                            color = Color(0xFF00E5FF), fontSize = 12.sp)
                        Slider(value = startSec,
                            onValueChange = { v ->
                                startSec = v.coerceAtMost((endSec - 0.5f).coerceAtLeast(0f))
                            },
                            valueRange = 0f..(durationMs / 1000f).coerceAtLeast(1f))
                        Text("Final: ${"%.1f".format(endSec)} s",
                            color = Color(0xFFFF8BE8), fontSize = 12.sp)
                        Slider(value = endSec,
                            onValueChange = { v ->
                                endSec = v.coerceAtLeast(startSec + 0.5f)
                            },
                            valueRange = 0.5f..(durationMs / 1000f).coerceAtLeast(1f))
                        Text("Para stickers animados, usá fragmentos cortos (máximo 10 segundos).",
                            color = Color.LightGray, fontSize = 11.sp)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF21183A)),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(17.dp)) {
                    Text("3. Crear resultado", color = Color.White,
                        fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(10.dp))
                    Button(
                        enabled = videoUri != null && !busy && (endSec - startSec) <= 10.0f,
                        onClick = {
                            val uri = videoUri ?: return@Button
                            busy = true
                            status = "Creando sticker animado…"
                            exportAnimatedWebp(context, uri, startSec, endSec) { file, error ->
                                busy = false
                                if (file != null) {
                                    status = "Sticker WebP creado: ${file.length() / 1024} KB"
                                    shareFile(context, file, "image/webp")
                                } else status = error ?: "No se pudo crear el sticker."
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Crear sticker animado (sin audio)")
                    }
                    OutlinedButton(
                        enabled = videoUri != null && !busy,
                        onClick = {
                            val uri = videoUri ?: return@OutlinedButton
                            busy = true
                            status = "Creando video con su sonido original…"
                            exportVideoWithAudio(context, uri, startSec, endSec) { file, error ->
                                busy = false
                                if (file != null) {
                                    status = "Video con audio creado"
                                    shareFile(context, file, "video/mp4")
                                } else status = error ?: "No se pudo exportar el video."
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VolumeUp, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Crear clip con el audio original")
                    }
                    if (busy) {
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("Procesando en tu teléfono…", color = Color.LightGray,
                            fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "El WebP animado no contiene sonido. El clip MP4 conserva el audio original y se envía como video por WhatsApp.",
                color = Color(0xFFBDB4D4), fontSize = 11.sp
            )
            Spacer(Modifier.weight(1f))
            Text("Versión 1.0 • Procesamiento local",
                color = Color(0xFF8D83A8), fontSize = 11.sp)
        }
    }
}

private fun copyUriToCache(context: android.content.Context, uri: Uri): File {
    val input = context.contentResolver.openInputStream(uri)
        ?: throw IllegalStateException("No se pudo abrir el video")
    val output = File(context.cacheDir, "input_${System.currentTimeMillis()}.mp4")
    input.use { src -> FileOutputStream(output).use { dst -> src.copyTo(dst) } }
    return output
}

private fun exportAnimatedWebp(
    context: android.content.Context, uri: Uri, start: Float, end: Float,
    done: (File?, String?) -> Unit
) {
    Thread {
        try {
            val input = copyUriToCache(context, uri)
            val output = File(context.cacheDir, "sticker_${System.currentTimeMillis()}.webp")
            val length = (end - start).coerceIn(0.5f, 10f)
            val command = "-y -ss ${start} -i ${quote(input.absolutePath)} -t ${length} " +
                "-an -vf \"fps=12,scale=512:512:force_original_aspect_ratio=decrease," +
                "pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black\" " +
                "-loop 0 -vcodec libwebp -lossless 0 -q:v 45 -compression_level 6 " +
                quote(output.absolutePath)
            val session = FFmpegKit.execute(command)
            if (ReturnCode.isSuccess(session.returnCode) && output.exists()) {
                if (output.length() > 500 * 1024) {
                    done(null, "El sticker supera 500 KB. Probá un fragmento más corto.")
                } else done(output, null)
            } else done(null, "No se pudo codificar WebP. Probá con otro video.")
            input.delete()
        } catch (e: Exception) {
            done(null, e.message ?: "Error al crear el sticker")
        }
    }.start()
}

private fun exportVideoWithAudio(
    context: android.content.Context, uri: Uri, start: Float, end: Float,
    done: (File?, String?) -> Unit
) {
    Thread {
        try {
            val input = copyUriToCache(context, uri)
            val output = File(context.cacheDir, "clip_audio_${System.currentTimeMillis()}.mp4")
            val length = (end - start).coerceAtLeast(0.5f)
            val command = "-y -ss ${start} -i ${quote(input.absolutePath)} -t ${length} " +
                "-map 0:v:0 -map 0:a? -c:v libx264 -preset ultrafast -crf 23 " +
                "-c:a aac -b:a 128k -movflags +faststart ${quote(output.absolutePath)}"
            val session = FFmpegKit.execute(command)
            if (ReturnCode.isSuccess(session.returnCode) && output.exists() && output.length() > 0) {
                done(output, null)
            } else done(null, "No se pudo exportar el MP4. Probá con otro video.")
            input.delete()
        } catch (e: Exception) {
            done(null, e.message ?: "Error al exportar el video")
        }
    }.start()
}

private fun quote(path: String): String = "\"" + path.replace("\"", "\\\"") + "\""

private fun shareFile(context: android.content.Context, file: File, mime: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(
        context, context.packageName + ".provider", file
    )
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Compartir resultado"))
}
